![[GameLore/DALL·E 2024-02-01 23.32.37 - A shadowy figure known as The Coveter , embodying the theme of envy, with a unique dual-faced mask. One face shows a longing gaze, desiring what othe.png]]

![[GameLore/DALL·E 2024-02-01 23.32.39 - A shadowy figure known as The Coveter , embodying the theme of envy, with a unique dual-faced mask. One face shows a longing gaze, desiring what othe.png]]

![[GameLore/DALL·E 2024-02-01 23.39.56 - A shadowy being known as _The Coveter,_ an Idol of Envy, is depicted with a unique dual-faced mask. One face shows a longing gaze, eyes fixed on treas.png]]




![[GameLore/DALL·E 2024-02-01 23.39.47 - A shadowy being known as _The Coveter,_ an Idol of Envy, is depicted with a unique dual-faced mask. One face shows a longing gaze, eyes fixed on treas.png]]

### The Coveter: Idol of Envy

#### Depiction in Art
- **Duality of Desire and Deception**: In art, "The Coveter" is a striking figure of contrasts, embodying the dual nature of envy. One face yearns openly, its eyes fixed on treasures just out of reach, while the other face wears a cunning smirk, plotting to seize what belongs to another. This duality is further emphasized by the play of light and shadow across their form, symbolizing the visible longing and the hidden machinations of envy.
- **Surrounded by Whispers**: Ethereal whispers and shadowy figures often encircle "The Coveter," representing the insidious spread of envy and the way it whispers sedition and discontent into the ears of mortals.

#### Realm: "The Mirror Halls"
- **Infinite Reflections of Desire**: "The Mirror Halls" are an elaborate, ever-expanding palace of mirrors, each surface reflecting not reality but the twisted desires of those who gaze upon it. These mirrors do not show what one has, but amplify the longing for what others possess, driving visitors into a frenzy of envy and covetousness.
- **Labyrinth of Treachery**: Navigating the Mirror Halls is a journey through one's own unsatisfied desires and unfulfilled ambitions. The pathways twist and turn, leading deeper into obsession, as reflections whisper temptations to betray, to deceive, to usurp. It's a realm where trust erodes, and friendships dissolve under the weight of growing envy.

#### Power to Mortals: The Gift of Green Eyes
- **Seduction of Undermining**: "The Coveter" bestows upon their followers the ability to charm, deceive, and manipulate, turning rivals against one another and undermining those they envy. This power can topple leaders, destroy alliances, and elevate the wielder on the backs of those they betray.
- **Curse of Never Enough**: However, this power comes with a curse. Those who employ it find that victory tastes like ashes. The more they gain through treachery, the greater their dissatisfaction grows. What they possess loses value the moment it's obtained, for the true object of desire is always that which belongs to another.
- **Insatiable Longing**: Ultimately, followers of "The Coveter" are doomed to an existence of perpetual longing. Their envy drives them to acquire more, but their achievements bring no joy. Relationships are poisoned by suspicion, and successes are tainted by the knowledge that they were gained through deceit.

#### Artistic and Narrative Symbolism
- **A Reflection on the Nature of Envy**: "The Coveter" and their realm serve as a profound commentary on the destructive nature of envy. Artistic depictions often include images of broken mirrors or reflections that distort and mar the beauty of what they show, symbolizing how envy distorts perception and values.
- **The Poison of Comparison**: Through "The Coveter," narratives explore the toxic effects of constant comparison and the pursuit of others' possessions or achievements. It's a cautionary tale about the emptiness of desires founded on envy, highlighting the importance of finding satisfaction and value in one's own life and accomplishments.

"The Coveter" thus emerges as a complex embodiment of envy, offering a powerful examination of the sin's ability to corrode the soul, undermine relationships, and leave its victims trapped in a cycle of perpetual dissatisfaction and longing.