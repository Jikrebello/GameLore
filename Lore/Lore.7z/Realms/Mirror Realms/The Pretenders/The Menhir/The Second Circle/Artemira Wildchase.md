![[DALL·E 2024-01-31 18.34.29 - Illustrate additional images of Artemira Wildchase, a celestial figure symbolizing the Constellation of the Hunt, without any text. She should have a .png]]

![[DALL·E 2024-01-31 18.34.30 - Illustrate additional images of Artemira Wildchase, a celestial figure symbolizing the Constellation of the Hunt, without any text. She should have a .png]]
![[DALL·E 2024-01-31 18.35.19 - Create more images of Artemira Wildchase, a celestial being representing the Constellation of the Hunt, similar to the style of the second image previ.png]]

![[DALL·E 2024-01-31 18.35.20 - Create more images of Artemira Wildchase, a celestial being representing the Constellation of the Hunt, similar to the style of the second image previ.png]]
- **Artemira Wildchase (Constellation of the Hunt)**
    - **Tragic Tale**: Artemira's wild pursuit once caused a celestial upheaval, disrupting the balance between day and night. As penance, she was placed in the sky, her hunt forever limited to the stars.
    - **Tragic Tale**: Artemira was transformed into a constellation after losing her mortal family to a beast she was hunting. Her constellation now chases the beast across the sky every night.
    - **Fearful Aspect**: Hunters and travelers are wary when Artemira's constellation is in full view, as it is believed to awaken the primal and savage aspects of both beasts and humans.