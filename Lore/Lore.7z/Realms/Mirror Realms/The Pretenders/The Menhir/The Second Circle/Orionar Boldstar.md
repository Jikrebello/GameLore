![[DALL·E 2024-01-31 18.08.10 - Create an image of Orionar Boldstar, a celestial being from a mythological tale, representing the Constellation of Courage. Orionar should have a huma.png]]

![[DALL·E 2024-01-31 18.08.11 - Create an image of Orionar Boldstar, a celestial being from a mythological tale, representing the Constellation of Courage. Orionar should have a huma.png]]

![[DALL·E 2024-01-31 18.09.05 - Depict Orionar Boldstar, a celestial figure from mythology, as the personification of the Constellation of Courage. He should have a humanoid form wit.png]]

![[DALL·E 2024-01-31 18.09.06 - Depict Orionar Boldstar, a celestial figure from mythology, as the personification of the Constellation of Courage. He should have a humanoid form wit.png]]

- **Orionar Boldstar (Constellation of Courage)**
	- **Tragic Tale**: Orionar's fiery courage led him to challenge the very boundaries of the sky set by his father, Aethon Solcara. His rebellion ended in sorrow, as he was cast into the heavens, his fiery spirit confined to the stars.
    - **Fearful Aspect**: Orionar's constellation is said to blaze brightest when wars loom, a grim reminder of the cost of unchecked bravery.