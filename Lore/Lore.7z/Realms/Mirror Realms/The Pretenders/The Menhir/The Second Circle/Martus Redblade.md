![[DALL·E 2024-01-31 18.19.44 - Visualize Martus Redblade, a celestial figure representing the Constellation of War. He should be a blend of human and celestial qualities, with a hum.png]]

![[DALL·E 2024-01-31 18.19.45 - Visualize Martus Redblade, a celestial figure representing the Constellation of War. He should be a blend of human and celestial qualities, with a hum.png]]
![[DALL·E 2024-01-31 18.20.20 - Depict more images of Martus Redblade, a celestial being embodying the Constellation of War. He should combine human and celestial elements, with a hu.png]]

![[DALL·E 2024-01-31 18.20.21 - Depict more images of Martus Redblade, a celestial being embodying the Constellation of War. He should combine human and celestial elements, with a hu.png]]
- **Martus Redblade (Constellation of War)**
    - **Tragic Tale**: Martus's aggression once threatened to consume the celestial realm. Aethon and Lunara, in a bid to temper his fiery war spirit, placed him in the sky, where his constant battle is with himself, reflected in the stars.
    - **Tragic Tale**: A great general who could never find peace, Martus was doomed to reflect his inner turmoil in the heavens, constantly reliving his battles.
    - **Fearful Aspect**: When bloodshed and conflict are imminent, Martus's constellation appears to bleed in the night sky, a portent of the violence to come.